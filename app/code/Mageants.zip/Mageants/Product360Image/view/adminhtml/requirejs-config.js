var config = {
	"map": {
	    "*": {
	    	"product360gallery": "Mageants_Product360Image/js/product360-gallery",
	    	"spritespin": "Mageants_Product360Image/js/spritespin.min"
	    }
	},
	paths: {
		'mageants/product360gallery': 'Mageants_Product360Image/js/product360-gallery',
		'mageants/spritespin': 'Mageants_Product360Image/js/spritespin.min'
	},
	shim: {
	}
};
