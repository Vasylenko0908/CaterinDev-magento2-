var config = {
	"map": {
	    "*": {
	    	"spritespin": "Mageants_Product360Image/js/spritespin.min"	  
	    }
	},
	paths: {
		'mageants/spritespin': 'Mageants_Product360Image/js/spritespin.min'
	},
	shim: {
        "Mageants_Product360Image/js/spritespin.min":["jquery"],
    }
};
