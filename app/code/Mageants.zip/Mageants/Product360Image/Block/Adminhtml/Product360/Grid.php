<?php
 /**
  * @category Mageants Product360Image
  * @package Mageants_Product360Image
  * @copyright Copyright (c) 2017 Mageants
  * @author Mageants Team <support@Mageants.com>
  */
namespace Mageants\Product360Image\Block\Adminhtml\Product360;

class Grid extends \Magento\Backend\Block\Widget\Grid
{

}
