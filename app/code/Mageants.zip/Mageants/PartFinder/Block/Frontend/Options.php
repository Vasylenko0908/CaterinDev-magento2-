<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\PartFinder\Block\Frontend;
 
use \Magento\Framework\View\Element\Template\Context;
use \Mageants\PartFinder\Model\ResourceModel\PartFinderOptionValues\CollectionFactory as PartFinderOptionValuesCollectionFactory;
use \Mageants\PartFinder\Helper\Data as PartFinderHelper;
/**
 * Class BlockRepository
 *
 * @package Mageants\PartFinder\Block\Frontend
 */
class Options extends \Magento\Framework\View\Element\Template
{
	/**
     * Collection Factory
     * 
     * @var \Mageants\PartFinder\Model\ResourceModel\PartFinderOptionValues\CollectionFactory
     */
    protected $_partFinderOptionValuesCollectionFactory;
    /**
     * @param Context $context,
	 * @param array $data = [],
	 * @param Data $helper,
	 * @param PartFindersFactory $partfindersFactory
     */
	public function __construct(
		Context $context,
		array $data = [],
		PartFinderOptionValuesCollectionFactory $partFinderOptionValuesCollectionFactory
	) {	
		parent::__construct($context, $data);
			
		$this->_partFinderOptionValuesCollectionFactory = $partFinderOptionValuesCollectionFactory;
		
	}
	/**
     * Retrieve PartFinder Selected Option 
     *
     * @return string
     */
	public function getSelectedOption()
	{
		$lavel= $this->getRequest()->getParam("lavel");
		
		$param = $this->getRequest()->getParam(PartFinderHelper::FINDER_KEY);
		
		$selected = "";
		
		if($param  && $param != "")
		{
			$options = explode("-",$param);
			
			if(isset($options[$lavel]))
			{
				$selected = $options[$lavel];
			}
		}
		
		return $selected;
	}
	/**
     * Retrieve PartFinder Option Children
     *
     * @return getFinderOptionChlidren
     */
	public function getFinderOptionChlidren()
	{
		$option_id = $this->getRequest()->getParam("id",true);
		
		$parent_id = $this->getRequest()->getParam("parent_id",true);
		
		$partFinderOptionValuesCollection = $this->_partFinderOptionValuesCollectionFactory->create()->addFieldToFilter("parent_id",$parent_id);
		
		if($parent_id==0)
		{
			$partFinderOptionValuesCollection->addFieldToFilter("option_id",$option_id); 
		}
		return $partFinderOptionValuesCollection;
	}}