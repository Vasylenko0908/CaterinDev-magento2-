var config = {
	"map": {
	    "*": {
	    	"partfinder": "Mageants_PartFinder/js/partfinder"
	    }
	},
	paths: {
		'mageants/partfinder': 'Mageants_PartFinder/js/partfinder'
	},
	shim: {
	}
};
