var config = {
	"map": {
	    "*": {
	    	"finedrop": "Mageants_PartFinder/js/jquery.fine-uploader",
			"partfinder": "Mageants_PartFinder/js/partfinder",
			"partfinderhistorylog": "Mageants_PartFinder/js/historylog",
			"partfinder-products": "Mageants_PartFinder/js/partfinder-products",
	    }
	},
	paths: {
		'mageants/finedrop': 'Mageants_PartFinder/js/jquery.fine-uploader',
		'mageants/partfinder': 'Mageants_PartFinder/js/partfinder',
		'mageants/partfinderhistorylog': 'Mageants_PartFinder/js/historylog',
		'mageants/partfinder-products': 'Mageants_PartFinder/js/partfinder-products',
	},
	shim: {
	}
};
