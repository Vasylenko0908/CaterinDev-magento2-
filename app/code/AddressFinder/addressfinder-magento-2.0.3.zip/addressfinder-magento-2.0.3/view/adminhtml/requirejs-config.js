var config = {
  paths: {
    magento_plugin: 'AddressFinder_AddressFinder/js/magento-plugin',
    addressfinder: 'https://api.addressfinder.io/assets/v3/widget'
  },
};
