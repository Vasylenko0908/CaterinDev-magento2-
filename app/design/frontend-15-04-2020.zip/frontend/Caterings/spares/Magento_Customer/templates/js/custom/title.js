
            
  JQuery(document).ready( function() {
    alert()
        JQuery('.columns').addClass('my-dashboard');
  });

